#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include "rotaryencoder.h"

struct encoder encoder;

main()
{
	printf("Starting...\n");

	wiringPiSetup();

	struct encoder *vol_selector = setupencoder(15,16);
	int old_vol_value = vol_selector->value;

	while(1)
	{
		if(old_vol_value != vol_selector->value)
		{
			old_vol_value = vol_selector->value;
			printf("\n%d\n", old_vol_value);
		}
	}

}
