#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>		//Required for utilising raspberry pi gpio
#include <mpd/client.h>		//Required for interfacing with mpc (mpd client)

#include "rotaryencoder/rotaryencoder.h"	//Required to interface a rotary encoder on the raspi gpio


#define vol_encoder_A 15	//Encoder channel A
#define vol_encoder_B 16	//Encoder channel B
#define mute_pin 1		//Mute button
#define debounce_ms 50		//Debounce value for toggling mute (in ms)

#define MUTE_OFF	0	//bool values to indicate current mute status
#define MUTE_ON		1

struct encoder encoder;				//Initialise encoder structure (refer "rotaryencode.h")
struct mpd_connection *connection = NULL;	//Initialise mpd (media player daemon) connection (refer "mpd/client.h")

//function required for initialising the mpd interface via mpc
//this function pulled straight from example code
static struct mpd_connection *setup_connection(void)
{
    struct mpd_connection *conn;

    conn = mpd_connection_new("127.0.0.1", 6600, 0);	//settings include IP address set to localhost and default mpd port
    if (conn == NULL) 
    {
        fputs("Out of memory\n", stderr);
        exit(EXIT_FAILURE);
    }
    return conn;
}

//function to return the current volume
int volume()
{
	struct mpd_status *status = mpd_run_status(connection);
	int volume = mpd_status_get_volume(status);
	mpd_status_free(status);
	return volume;
}

int main()
{
//	printf("Starting...\n");

	wiringPiSetup();	//initialise raspi to interface with gpio

	pinMode (mute_pin, INPUT);		//set the pin to which the mute button is connected as an input
	pullUpDnControl (mute_pin, PUD_UP);	//enable internal pull-up resistor on mute pin

	struct encoder *vol_selector = setupencoder(vol_encoder_A,vol_encoder_B);	//initailise encoder interface
	if(vol_selector == NULL) { exit(1); }						//exit if encoder initialisation fails
	int old_vol_value = vol_selector->value;					//pre-loop initialisation

	bool mute_status = MUTE_OFF;	//Initialises mute status.  0: No mute, 1: Mute
	int pre_mute_vol = 0;		//Initialise pre-mute volume (used to return volume value after de-mute)

	connection = setup_connection();	//initialise mpc connection session
//	printf("\nConnected\n");

	//main programme loop
	while(1)
	{
		if(old_vol_value != vol_selector->value)	//if the encoder value has changed
		{
			int change = vol_selector->value - old_vol_value;	//quantify the amount by which the encode value has changed
			mpd_run_change_volume(connection, change);		//adjust the volume accordingly
			old_vol_value = vol_selector->value;			//update known encoder value
//			printf("\nVolume: %d\%%\n", volume());			//print new volume level to screen
		}

		if(digitalRead(mute_pin) == 0)		//if mute button has been pushed
		{
			delay(debounce_ms);		//wait for a "debounce" duration
			if(digitalRead(mute_pin) == 0)	//check if the mute button is still pushed
			{
//				printf("\nMute Toggled\n");
				if(mute_status == MUTE_OFF)				//if not currently muted
				{
					pre_mute_vol = volume();			//remember pre-bute volume
					mpd_run_set_volume(connection, 0);		//mute (i.e. set volume to 0)
					mute_status = MUTE_ON;				//update mute status
				}
				else if(mute_status == MUTE_ON)				//if currently muted
				{
					mpd_run_set_volume(connection, pre_mute_vol);	//return volume to pre-mute value
					mute_status = MUTE_OFF;				//update mute status
				}
				while(digitalRead(mute_pin) == 0) {}			//infinite loop until mute button is released
			}
		}
	}

	return 0;
}
