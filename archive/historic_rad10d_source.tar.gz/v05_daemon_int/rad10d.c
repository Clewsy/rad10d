#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>		//required for daemonisation
#include <sys/stat.h>		//required for daemonisation

#include <mpd/client.h>				//Required to interface with mpc (mpd client)
#include <wiringPi.h>				//Required for utilising raspberry pi gpio
#include "rotaryencoder/rotaryencoder.h"	//Required to interface a rotary encoder on the raspi gpio

#define vol_encoder_A 15	//Encoder channel A
#define vol_encoder_B 16	//Encoder channel B
#define mute_pin 1		//Mute button
#define debounce_ms 50		//Debounce value for toggling mute (in ms)

#define MUTE_OFF	0	//bool values to indicate current mute status
#define MUTE_ON		1

struct encoder encoder;				//Initialise encoder structure (refer "rotaryencode.h")
struct mpd_connection *connection = NULL;	//Initialise mpd (media player daemon) connection (refer "mpd/client.h")

//function required for initialising the mpd interface via mpc
//this function pulled straight from example code
static struct mpd_connection *setup_connection(void)
{
	struct mpd_connection *conn;

	conn = mpd_connection_new("127.0.0.1", 6600, 0);	//settings include IP address set to localhost and default mpd port
	if (conn == NULL) 
	{
		exit(EXIT_FAILURE);
	}
	return conn;
}

//function to return the current volume
int volume()
{
	struct mpd_status *status = mpd_run_status(connection);
	int volume = mpd_status_get_volume(status);
	mpd_status_free(status);
	return volume;
}

bool mute_status = MUTE_OFF;	//Global variable required for ISR - Initialises mute status.  0: No mute, 1: Mute
int pre_mute_vol = 0;		//Global variable required for ISR - Initialise pre-mute volume (used to return volume value after de-mute)
void muteISR (void)
{
	delay(debounce_ms);				//wait for a "debounce" duration
	if(digitalRead(mute_pin) == 0)			//check if the mute button is still pushed
	{
		if(mute_status == MUTE_OFF)				//if not currently muted
		{
			pre_mute_vol = volume();			//remember pre-bute volume
			mpd_run_set_volume(connection, 0);		//mute (i.e. set volume to 0)
			mute_status = MUTE_ON;				//update mute status
		}
		else if(mute_status == MUTE_ON)				//if currently muted
		{
			mpd_run_set_volume(connection, pre_mute_vol);	//return volume to pre-mute value
			mute_status = MUTE_OFF;				//update mute status
		}
		while(digitalRead(mute_pin) == 0) {}	//infinite loop until mute button is released
	}
}

int main(int argc, char* argv[])
{
	//Start with code to implment daemonisation

	pid_t pid = 0;	//initialise pid (process id)
	pid_t sid = 0;	//initialise sis (session id)

	pid = fork();	//fork off rom the parent process.  fork() should return PID of child process
	if (pid < 0)	//if fork returns a value less than 0 then an error has occured
	{
		exit(EXIT_FAILURE);	//exit the parent process but return failure cose
	}
	if (pid > 0)	//if fork returns a positive value then we have successfully forked a child process from the parent process
	{
		exit(EXIT_SUCCESS);	//exit the parent process successfully
	}

	umask(0);	//unmask the file mode - allow the daemon to open, read and write any file anywhere

	sid = setsid();	//set new session and allocate session id.  if successful, child process is now process group leader
	if(sid < 0) { exit(EXIT_FAILURE); }//if setsid fails, exit

	//Change Directory
	//If we cant find the directory we exit with failure.
	if ((chdir("/")) < 0) { exit(EXIT_FAILURE); }

	//daemons should not involve any standard user interaction so close stdin, stdout and stderr
	close(STDIN_FILENO);
	close(STDOUT_FILENO);
	close(STDERR_FILENO);

////////////////////////////////////////////////////////////////////////////////////////////////
////////	The Payload - at this ponit, the programme is running as a daemon	////////
////////////////////////////////////////////////////////////////////////////////////////////////

	if (wiringPiSetup() < 0) { exit(EXIT_FAILURE); }	//initialise raspi to interface with gpio, exit if failure

	pinMode (mute_pin, INPUT);		//set the pin to which the mute button is connected as an input
	pullUpDnControl (mute_pin, PUD_UP);	//enable internal pull-up resistor on mute pin

	struct encoder *vol_selector = setupencoder(vol_encoder_A,vol_encoder_B);	//initailise encoder interface
	if(vol_selector == NULL) { exit(EXIT_FAILURE); }				//exit if encoder initialisation fails
	int old_vol_value = vol_selector->value;					//pre-loop initialisation

//	bool mute_status = MUTE_OFF;	//Initialises mute status.  0: No mute, 1: Mute
//	int pre_mute_vol = 0;		//Initialise pre-mute volume (used to return volume value after de-mute)

	connection = setup_connection();        	//initialise mpc connection session
	if (connection < 0) { exit(EXIT_FAILURE); }	//exit if failure to setup mpd connection

	if (wiringPiISR (mute_pin, INT_EDGE_FALLING, &muteISR) < 0) { exit(EXIT_FAILURE); } //set up interrupt on the mute button

	//the main infinite loop
	while (1)
	{
		while(old_vol_value == vol_selector->value)
		{
			delay(10);
		}

		//if the following lines are reached it's because the encoder has moved
		int change = vol_selector->value - old_vol_value;	//quantify the amount by which the encode value has changed
		mpd_run_change_volume(connection, change);		//adjust the volume accordingly
		old_vol_value = vol_selector->value;			//update known encoder value
	}

	return (0);
}
