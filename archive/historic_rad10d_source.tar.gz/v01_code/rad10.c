#include <stdio.h>
#include <stdlib.h>
#include <wiringPi.h>
#include <mpd/client.h>

#include "rotaryencoder/rotaryencoder.h"

#define vol_encoder_A 15	//pin for volume control rotary encoder channel A
#define vol_encoder_B 16        //pin for volume control rotary encoder channel B
#define mute_pin 1		//pin to which the mute button is connected
#define debounce_ms 50		//button debounce duration in milliseconds required for a button press to register

struct encoder encoder;
struct mpd_connection *connection = NULL;

static struct mpd_connection *setup_connection(void)
{
    struct mpd_connection *conn;

    conn = mpd_connection_new("127.0.0.1", 6600, 0);
    if (conn == NULL) 
    {
        fputs("Out of memory\n", stderr);
        exit(EXIT_FAILURE);
    }
    return conn;
}


//returns current volume setting (integer from 0 to 100)
int volume()
{
	struct mpd_status *status = mpd_run_status(connection);
	int volume = mpd_status_get_volume(status);
	mpd_status_free(status);
	return volume;
}

int main()
{
	printf("Starting...\n");

	wiringPiSetup();

	pinMode (mute_pin, INPUT);		//set mute button pin to an input
	pullUpDnControl (mute_pin, PUD_UP);	//activale the internal pull-up resistor on the mute button pin

	struct encoder *vol_selector = setupencoder(vol_encoder_A,vol_encoder_B);	//enable the rotary encoder
	if(vol_selector == NULL) { exit(1); }
	int old_vol_value = vol_selector->value;					//initialise the old volume

	bool mute_status = 0;   //0: No mute, 1: Mute
	int pre_mute_vol = 0;	//initialise the volume setting prior to activating mute

	connection = setup_connection();
	printf("\nConnected\n");

	while(1)
	{
		if(old_vol_value != vol_selector->value)
		{
			int change = vol_selector->value - old_vol_value;

			mpd_run_change_volume(connection, change);

			old_vol_value = vol_selector->value;

			printf("\nVolume: %d\%%\n", volume());
		}

		if(digitalRead(mute_pin) == 0)
		{
			delay(debounce_ms);
			if(digitalRead(mute_pin) == 0)
			{
				printf("\nMute Toggled\n");
				if(mute_status == 0)
				{
					pre_mute_vol = volume();
					mpd_run_set_volume(connection, 0);
					mute_status = 1;
				}
				else if(mute_status == 1)
				{
					mpd_run_set_volume(connection, pre_mute_vol);
					mute_status = 0;
				}
				while(digitalRead(mute_pin) == 0) {}
			}
		}
	}

	return 0;
}
